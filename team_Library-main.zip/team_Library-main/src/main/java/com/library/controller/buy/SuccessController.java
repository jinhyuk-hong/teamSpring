package com.library.controller.buy;

import org.springframework.stereotype.Controller;

@Controller
public class SuccessController {

}
