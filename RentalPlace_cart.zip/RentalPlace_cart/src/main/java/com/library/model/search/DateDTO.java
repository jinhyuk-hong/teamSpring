package com.library.model.search;

import lombok.Data;

@Data
public class DateDTO {

	private String year;
	private String month;
}
